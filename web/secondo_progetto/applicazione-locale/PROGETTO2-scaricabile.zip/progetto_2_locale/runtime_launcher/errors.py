class StartupError(RuntimeError):
    pass
